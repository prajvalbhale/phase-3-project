package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminRepo extends JpaRepository<Admin, Integer>{

	@Query(value = "select a from Admin a where a.username=?1", nativeQuery = true)
	public Admin FindUsername(String username);
	
	@Query(value ="select a from Admin a where a.pass=?1", nativeQuery =  true)
	public Admin FindPass(String pass);
	
}